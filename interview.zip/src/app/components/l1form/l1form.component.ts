import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-l1form',
  templateUrl: './l1form.component.html',
  styleUrls: ['./l1form.component.css']
})
export class L1formComponent implements OnInit {
  name: any;

  constructor() { }

  ngOnInit() {
    
  }
 public showRate;
    public selectionModel;
    public data = [
        {
          id: 1,
          name: "Muthu",
        },
        {
          id: 2,
          name: "Jeeva",
        },
        {
          id: 3,
          name: "Gokul",
        }
      ];

  public rateData:any[]=[
        {
          rate: 10,
          name: "Muthu",
        },
        {
          rate: 20,
          name: "Jeeva",
        },
        {
          rate: 30,
          name: "Gokul",
        }
  ]
      onChange() {    
        this.name = this.selectionModel.name;

       

       //For more Result use filter method
        this.showRate=this.rateData.filter((o)=>o.name == this.selectionModel.name) ;

     console.log("Your Filtered Data Here",this.showRate);
      }
}
