import { NgModule } from '@angular/core';
import { Routes, RouterModule,PreloadAllModules   } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { AddproductComponent } from './components/addproduct/addproduct.component';
import { EditproductComponent } from './components/editproduct/editproduct.component';
import { ProductsComponent } from './components/products/products.component';
import { UserloginComponent } from './components/userlogin/userlogin.component';
import { FormComponent } from './components/form/form.component';
import { L1formComponent } from './components/l1form/l1form.component';
import { L2formComponent } from './components/l2form/l2form.component';





const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'products',component:ProductsComponent},
  {path:'addproduct',component:AddproductComponent},
  {path:'editproduct',component:EditproductComponent},
  {path:'userlogin', component:UserloginComponent},
  {path:'form', component:FormComponent},
  {path:'l1form', component:L1formComponent},
  {path:'l2form', component:L2formComponent},



];

@NgModule({
  imports: [RouterModule.forRoot(routes, {preloadingStrategy: PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
